export const paletteAnimations = {};
