export const polygonAnimations = {};
