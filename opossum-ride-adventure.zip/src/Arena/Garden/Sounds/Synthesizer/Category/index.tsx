export const GardenSoundCategory = {};
