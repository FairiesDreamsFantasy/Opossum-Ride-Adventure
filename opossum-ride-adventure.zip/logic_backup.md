# Opossum Ride Adventure - Logic Backup & Master Specification

**Game Title:** Opossum Ride Adventure  
**License:** GNU General Public License v3 (GPL v3) & Creative Commons Attribution-ShareAlike 4.0 (CC-BY-SA-4.0)  
**Authorship & Sovereignty:** Fairies Dreams & Fantasy  
**Version:** 0.1.0.7.9  
**Branch Targets:** WorkspaceSync / Stable / Staging / System-Characters-Opossums-Protection-Shield / System-Sound-SFX-Opossum-Chatter-Shield / System-AI-InGame-Stabilization-Shield  
**Milestone Release:** v0.1.0.7.9 - 24 Sacred Female Opossums Expansion (32 Total) & 8 Riders Master Standardization

---

## 1. Architecture Overview
- **Framework:** React 19 + TypeScript + Vite.
- **Styling:** Tailwind CSS with comprehensive design tokens.
- **Physics Engine:** Hamiltonian Quaternion rotation, Runge-Kutta 4 (RK4) integration, Simpson's 1/3 numerical integration.
- **DSP Sound Engine:** Radix-2 Cooley-Tukey FFT, Karplus-Strong physical string synthesis, Schroeder 4-comb 2-allpass reverberators, dedicated compact and standard opossum SFX generators.
- **AI & Rate Limiting:** Dual Token Bucket Rate Limiter, Hard Quota Floor Shield, zero unhandled API exceptions. Native game functions isolated from external API keys.

---

## 2. Character Registry & Passel Hierarchy (19 Sacred Female Opossums + Crafted Jacks)

### Rose Passel
1. **Saffron Rose (Jill)**
   - Shoulder Height: 5 feet 11 inches | Length: 95 inches | Body Fur: Red-Orange | Skin: Wheat Tan
   - Tail: Gold with pink spiral wrap | Ears: Long, Upright, neon saffron polka-dots
2. **Jahmella Rose (Jill)**
   - Shoulder Height: 6 feet | Length: 99.5 inches | Body Fur: Orange with white circles | Skin: Tan
   - Tail: Deep Pink with gold spiral | Ears: Conventional, Upright
3. **Agape Rose (Jill)**
   - Shoulder Height: 5 feet 5 inches | Length: 90.1 inches | Body Fur: Gold with pink circles bordered in purple
   - Tail: Deep Pink with 2% gold fur | Ears: Conventional, Forward Leaning
4. **Kady Rose (Jill)**
   - Shoulder Height: 5 feet 11 inches | Length: 95 inches | Body Fur: Light Gray with bronze ear circles | Skin: Honey Dark-Brown
   - Tail: Red-Orange | Ears: Long, Upright
5. **Daisy Rose (Jill - Crafted)**
   - Shoulder Height: 6 feet, and 1.00123 inches | Length: 97.5 inches (8 feet, 1.5 inches) | Width: 44.0 inches
   - Fur: Pink base coat with 4-inch yellow daisy flowers surrounded by 1.5011cm blue borders spaced 2.5013in apart | Skin: Light Peach with warm undertone (2% tan hue, 0% furry face coverage)
   - Tail: Pink base with light yellow 1.44cm spiral (30% longer tail scale) | Ears: Upright pink with dark pink inner (4% larger scale) | Eyes: Blue | Nose: Dark-pink (no nostrils)
   - Accessories: Gold tiara with light yellow gem & blue border diamond sun; green chain diamond necklace with 14in diamond charm
6. **Callie Rose (Jill - Crafted)**
   - Shoulder Height: 5 feet, 11.444401003 inches | Length: 95.8888 inches (7 feet, 11.8888 inches) | Width: 40.5 inches
   - Fur: Yellowish-gold base coat with 4.5-inch blue circles surrounded by 1.8cm indigo borders spaced 3in apart | Skin: Tan with warm undertone (0% furry face coverage)
   - Tail: Red-gold | Ears: Upright yellowish-gold (30% longer, 5% larger scale) | Eyes: Green | Nose: Red-gold
   - Accessories: White gold brass circular reading glasses; blue tiara with 6in vertical emerald gem; violet diamond necklace with 3.5in orange circular charm
7. **Eugene Rose (Jack - Compact Crafted)**
   - Shoulder Height: 3 feet 10.00932 inches | Length: 6 feet (72 inches) | Width: 28 inches | Head Width: 26.5 inches | Head Height: 28 inches
   - Fur: Light-Gray (`#9CA3AF`) | Skin: Peach (`#FFEDD5`) | Paws: White (`#FFFFFF`) | Paw Pads: Peach (`#FFEDD5`)
   - Outer Ears: Dark-Gray (`#374151`), Upright, Conventional
   - Inner Ears: Pink (`#EC4899`) | Nose: Pink (`#EC4899`) | Tail: Pink (`#EC4899`), Hairless (0% fur)
   - Eyes: Green (`#10B981`) | Furry Face: 100% standard furry face
   - Religion: Rastafari or Shintoism | Babylon-Free: True
   - Resemblance: 89.9% real-world opossum resemblance
   - Vocation: Amusement park opossum ride operator providing safe rides for idren, dwarfs, and small riders
   - Lore: Born into the Rose passel, developed lactose intolerance growth restrictions (2'5" at age 8, maturing at 3'10.1"). Embraces Japanese culture, anime, writing, gaming, and farming.

### Jasmine Passel
1. **Stacey Jasmin (Jill - Crafted)**
   - Shoulder Height: 5 feet, 8.999 inches | Length: 95.9988 inches (7.9999 feet) | Width: 38.5 inches
   - Fur: Purple base coat with yellow saddle (beagle pattern, 35% thicker fur) | Skin: Tan with yellowish undertone (0% furry face coverage)
   - Tail: Dark-pink | Ears: Upright purple with dark-pink inner lining | Eyes: Indigo | Nose: Dark-pink (no nostrils)
   - Accessories: White gold tiara with circular yellow moon gem
2. **Dale Jasmine (Jill - Crafted)**
   - Shoulder Height: 5 feet and 7.123 inches | Body Length (excl head & tail): 7.1234 inches | Width: 38.88 inches
   - Head Width: 37.77 inches | Head Height: 44.88 inches | Fur: Lavender base with green 3.777-inch roses spaced by 3.001 inches
   - Skin: Peach (0% furry face) | Nose: Pink (no nostrils) | Tail: Pink (20% longer for scale) | Paws: White, pink pads
   - Ears: Lavender solid upright (medium-long), pink inner | Eyes: Light-Green | Accessories: Gold diamond necklace with 12.5-inch horizontal diamond charm
   - Chatter Pitch: +0.008% higher than Stacey Jasmin (1278.6822864 Hz -> 442.6154064 Hz)
   - Sistren of Stacey; Triplet of Qi & Jamie; Lunar Leadership; Food Safety Advocate; Rastafari only; Primary White.
3. **Qi Jasmine (Jill - Crafted)**
   - Shoulder Height: 5 feet and 7.123 inches | Body Length: 7.1234 inches | Width: 38.88 inches | Head Width: 37.77 inches | Head Height: 44.88 inches
   - Fur: Blue base with green 4.8-inch diameter circles spaced by 1.88 inches | Skin: Peach (0% furry face) | Nose: Pink (no nostrils) | Tail: Pink
   - Paws: Yellow, pink pads | Ears: Blue upright, pink inner | Eyes: Light-Blue | Accessories: Silver diamond necklace with 11.5-inch circular diamond charm
   - Chatter Pitch: +0.002% higher than Dale Jasmine (1278.7078600 Hz -> 442.6242587 Hz)
   - Sistren of Stacey; Triplet of Dale & Jamie; Lunar Leadership; Anti-Poaching Tech Specialist; Rastafari only; Primary White.
4. **Jamie Jasmine (Jill - Crafted)**
   - Shoulder Height: 5 feet and 7.123 inches | Body Length: 7.1234 inches | Width: 38.88 inches | Head Width: 37.77 inches | Head Height: 44.88 inches
   - Fur: Solid Silver | Skin: Tan (0% furry face) | Nose: Red-Orange (no nostrils) | Tail: Red-Orange (20% longer for scale)
   - Paws: Gold, red-orange pads | Ears: Silver upright (long), red-orange inner | Eyes: Indigo
   - Chatter Pitch: +0.008% higher than Qi Jasmine (1278.8101567 Hz -> 442.6596686 Hz)
   - Sistren of Stacey; Triplet of Dale & Qi; Weather Scientist & Anti-Poaching Decoy; Rastafari only; Primary White.

### Kone-Reynolds Family
1. **Dagmar Kone-Reynolds (Jill)**: 5' 8.5" shoulder height, white with multi-colored diamond pattern.
2. **Arden-Rosie Kone-Reynolds (Jill)**: 5' 1.5" shoulder height, cream with diamond patterns.
3. **Roxanne Kone-Reynolds (Jill)**: 6' shoulder height, yellow with red-orange bordered diamonds.
4. **Ruth Kone-Reynolds (Jill)**: 6' shoulder height, pink with 25-color flower pattern.
5. **Drake Kone-Reynolds (Jack - Compact Crafted)**: 4' shoulder height, 6' body length, red with 7 silver stripes, forward-leaning ears.
6. **Rudy Kone-Reynolds (Jack - Compact Crafted)**: 3' 7.5" shoulder height, 64" body length, yellow with brown circles, side-down ears.

### Qin Family & Chin Family
- **Amara Qin (Jill)**: 5' 3" shoulder height, pure white, blue eyes.
- **Tiana Qin (Jill)**: 5' 10" shoulder height, red, blue eyes.
- **Melvin Qin (Jack - Compact Crafted - 'M' in D-R-E-A-M-S)**: 3.5 ft shoulder height, 68" body length, 34" width, 32" head width, 30" head height excluding ears. Light-tan coat, peach with yellowish hue skin, 50% furry face, red outer ears, brown inner ears (downward, side-oriented), dark-green eyes, brown nose & tail, white paws. Shintoism only, Japanese/American ethnicity. Authentic procedural opossum bark. Amara's brother-in-law.
- **Jalissa Chin (Jill)**: 5' 1" shoulder height, yellow-orange.
- **Olivia Chin (Jill)**: 5' 1" shoulder height, blond, indigo eyes.
- **Safford Chin (Jack - Compact Crafted - 'S' in D-R-E-A-M-S)**: 3' 10.0000088" shoulder height, 72" body length (6 ft), 28.5" width, 27" head width, 28" head height excluding ears. Light-Blue coat, cream skin, 2% furry face, solid brown upright ears, light-brown eyes, black nose, black tail (hairless), black paws & pads. Buddhism only, White ethnicity. Builder vocation, Kansas factory explosion resilience. Authentic procedural opossum-like bark. Jalissa Chin's brother-in-law.

### The D-R-E-A-M-S Jack Opossums Acrostic (Compact Crafted)
1. **D** - Drake Kone-Reynolds
2. **R** - Rudy Kone-Reynolds
3. **E** - Eugene Rose
4. **A** - Arnold Rose
5. **M** - Melvin Qin
6. **S** - Safford Chin
7. **Ivan Opossum**
8. **Isaac Opossum**

### Other Crafted Opossums (Opossum Passel)
- **Melissa (Jill)**: 5' 3" shoulder height, light gray.
- **Ashley (Jill)**: 5' 3" shoulder height, yellow.
- **Wanda (Jill)**: 5' 2.9999" shoulder height, light amber, indigo eyes.
- **Sandra (Jill)**: 5' 3" shoulder height, lavender.
- **Jacinta Opossum (Jill - Crafted)**: 5' 3" shoulder height, 86" length, 36" width, solid red coat, red outer ears, pink inner ears, red-orange nose (no nostrils), peach skin, dark-green eyes, white paws with red-orange pads. Twin sistren of Camryn, in-law of Melissa & Ashley. Gardener, scientist & poacher hunter. Chatter pitch +1.0% above Melissa (1313.0 Hz -> 454.5 Hz).
- **Camryn Opossum (Jill - Crafted)**: 5' 3" shoulder height, 86" length, 36" width, solid light green coat, light-green outer ears, pink inner ears, pink nose (no nostrils), olive-undertone tan skin, blue eyes, gold paws with pink pads. Twin sistren of Jacinta, in-law of Melissa & Ashley. Scientist, gardener & poacher hunter. Chatter pitch +1.5% above Jacinta (1332.695 Hz -> 461.3175 Hz).

---

## 3. Master Design Attribute Lookup Maps
All 19 crafted opossums are fully synchronized across 38 design property lookup maps in `src/System/Registry/Characters/Opossums/Attributes/Design/index.tsx`:
- `Skin_Color`, `With_Patterns`, `Fur_Color`, `Tail_Color`, `Tail_Color_With_Design`, `Nose_Color`, `Shoulder_Height`, `Body_Width`, `Body_Length_excluding_head_and_tail`, `Full_Body_Length`, `Head_Width`, `Head_Height_excluding_ears`, `Full_Head_Height`, `Total_Height_excluding_ears`, `Total_Height`, `Eye_Color`, `Snout_Length`, `Furry_Face`, `Accessories`, `Tail_Length`, `Ear_Orientation`, `Ear_Length`, `Paw_Color`, `Paw_Pad_Color`, `Ear_Color`, `Inner_Ear_Color`, `Ear_Color_With_Patterns`, `Head_Fur_Color`, `_Furry_Face_Color`, `Body_Fur_Thickness`, `Furry_Tail_Percentage`, `Paw_Size`, `Leg_Length`, `Paw_Width`, `Leg_Width`, `Has_Elegant_Chatter`, `Has_Elegant_Trot`, `Tail_Thickness`.

---

## 4. Security & Protection Covenant
- All 4,581+ directories contain an active `AGENTS.md` shield.
- ZERO stubbing, ZERO simplifications, ZERO deletions.
- Full verification recorded in `PROTECTIONS_NOTICES.md`.

---

## 5. Accessibility Narration & Modular Arena Hierarchy
- **Subsystem**: `src/System/AI/In-Game/Category/Accessibility/Narration/`
- **Zero-Omission Standard**:
  - **In-Game Welcome / Mount Narration (`compileRidden`)**:
    "You are riding [name], an esteemed [Gender] opossum mount. [sub] stands at a shoulder height of [shoulder height], with a body width of [width] inches and a body length of [length] inches. Coat: [fur] ([coat pattern]). [possessive] face skin is [skinLabel]. Eyes: [eyes]. Nose: [nose]. Tail: [tail]. Ears: [outerEarDesc], set in a [earLengthTerm] [earOrientTerm] orientation, and lined with a delicate [innerEars] inner-ear lining. [faceText] [feetText] [tailText] [accText] [possessive] head orientation is [pose]. Background: [description]"
  - **Selection Screen 'r' Press (`compileSelection`)**:
    "Profile of [name]. [visual signature and complete aesthetic physical description] [pronoun] features a body length of [length] inches, with a body width of [width] inches and a registered shoulder height of [shoulder height]. Perfect spacing accommodates rider heights of up to [feet] feet and [inches] inches comfortably. Nose: [nose]. Eyes: [eyes]. Background: [description]"
- **23 Individualized Opossum Profile Modules**: Each with dedicated `index.tsx` and `AGENTS.md` in `Mount/Profiles/`.
- **Modular Arenas (`Narration/Arena/`)**:
  - `Foyer/`: Floor Foyer coordinate narration (`position X, Y`), Sabine RT60 reverberance, subarenas (Entrance, Grand Tapestry Alcove, Southwest Ramp, Perimeter Walkway, Dishwasher Room).
  - `Garden/`: Garden Arena, Zen Stone Garden, Botanical Maze, Sanctuaries, Orchards, Groves, Farms.
  - `Cellar/`: Grand Cellar subterranean limestone corridors, oak aging chambers.
  - `Porch/`: Southwest Porch, 4,000-foot perimeter walkway, veranda overlook.
  - `Registry.tsx`: Dynamic routing without hard-coded conditional chains.
- **Welcome Message Subsystem (`Narration/Welcome_Message/` & `Registry/Description/Welcome_Message/`)**:
  - `WelcomeMessageEngine.compileWelcomeMessage`: Dynamic Manor welcome announcement combining game credits, accessible control guidance for Cedella and Arden Denis keyboard layouts, Speech stop directives, and full un-diluted mount narration from `MountNarrationEngine.compileRiddenOpossumProfile(opossum)` (with shoulder height, body width, length, coat pattern, ears, paws, nose, eyes, and lore).
  - Eliminates hardcoded strings from `src/System/UI/Play_Area/index.tsx`.
- **Special Protection Branch**: `System-AI-InGame-Stabilization-Shield` recorded and enforced.
- **Tracking & Synchronization**: Pushed and recorded in `WorkspaceSync` and merged to `Stable` at version `0.1.0.7.8`.

---

## 6. Milestone 0.1.0.7.8 Verification & Release Notes
- **Version Number**: `0.1.0.7.8`
- **Stage**: Stable Production
- **Elimination of Hard-Coding**:
  1. Accessibility narrations for opossums modularized into 23 distinct profile handlers with dual compilation modes (`compileRidden` and `compileSelection`).
  2. Manor arenas and coordinates split into modular domain packages (`Foyer`, `Garden`, `Cellar`, `Porch`).
  3. Manor entrance welcome message decoupled from UI view logic into `Narration/Welcome_Message/` and `Registry/Description/Welcome_Message/`.
  4. Dynamic binding of `VersionRegistry.current` across Landing Page, Footer, and Play Area.
- **Branch Synchronization State**:
  - `WorkspaceSync`: Synchronized (Active workspace sync branch with chatter protection)
  - `Stable`: Synchronized (Production baseline)
  - `Staging`: Synchronized (Special testing branch for upcoming improvements)
  - `System-Characters-Opossums-Protection-Shield`: Active shield branch ensuring crafted characters (19 female opossums, 4 jack opossums) are immune to automated overwriting
  - `System-Sound-SFX-Opossum-Chatter-Shield`: Dedicated chatter protection branch ensuring the 19 sacred female opossums' anti-clicking DSP engine remains preserved
  - `System-AI-InGame-Stabilization-Shield`: Active shield branch for narration and accessibility systems

---

## 7. Compact Steed Fleet UI Logic & Rider Calibration Standard
- **Crafted Compact Roster (D-R-E-A-M-S Acrostic)**:
  1. Drake Kone-Reynolds (`drake_kone_reynolds`): Red, 7 silver stripes, forward-leaning ears, 4'0" shoulder height.
  2. Rudy Kone-Reynolds (`rudy_kone_reynolds`): Yellow with brown circles, side-down ears, 3'7.5" shoulder height.
  3. Eugene Rose (`eugene_rose`): Light-gray, upright ears, 3'10.00932" shoulder height.
  4. Arnold Rose (`arnold_rose`): Matte white with dark-brown ovals, forward-leaning ears, 3'8" shoulder height.
  5. Melvin Qin (`melvin_qin`): Light-tan, side-down dog-like ears, 3.5' (42") shoulder height, Japanese/American Americana researcher, Shintoism.
  6. Safford Chin (`safford_chin`): Light-blue, upright ears, 3'10.0000088" shoulder height, builder, employment and finance, Buddhism.
- **Fleet Balancing Formulation**:
  - Generic Compact Opossums adjusted from 60 to 58 by removing `compact_copper_orange` and `compact_bronze_black`.
  - Total Fleet: $6\text{ Crafted Jacks} + 58\text{ Generic Jills} = 64\text{ Steeds}$ (perfect 8x8 grid compatibility).
- **Rider Height Calibration Algorithm**:
  - **Upper Bound**: 4 feet and 4.44 inches ($52.44\text{ inches}$).
  - **Formula**: $H_{\text{max}} = (4 \times 12) + 4.44 = 52.44\text{ inches}$.
  - **Compatibility**: Sean White ($39\text{ in} \le 52.44\text{ in}$) and George Blake ($52\text{ in} \le 52.44\text{ in}$) comfortably cleared.
  - **Code Standard**: `COMPACT_RIDER_HEIGHT_LIMITS` with `isRiderEligible`, `parseRiderHeightInches`, and `calculateCompactMaxRiderHeight`.
- **Branch Tracking**:
  - Synced to `WorkspaceSync` and `Stable`.

---

## 8. Ivan Opossum & Isaac Opossum Integration Specification
- **Crafted Compact Roster Expansion**:
  - **7. Ivan Opossum (`ivan_opossum`)**: Pink coat base with 48 vertical brown stripes, 3' 2.5" (38.5") shoulder height, red tail/nose, black outer ears, dark-brown inner ears, 100% furry face, Hinduism, White ethnicity, former US military veteran and poacher hunter.
  - **8. Isaac Opossum (`isaac_opossum`)**: Light-Gray coat base with 8 evenly spaced dark-brown stripes of even thickness, 3' 1.5" (37.5") shoulder height, natural opossum skin/tail/ears, dark-brown eyes, 100% furry face, Buddhism, White ethnicity, former US military veteran and poacher hunter.
- **Passel Linkage**:
  - True brothers via Opossum passel (`Passel/Opossum/Ivan` and `Passel/Opossum/Isaac`).
  - In-laws of Melissa, Ashley, Wanda, and Sandra Opossum.
- **Fleet Balancing Formulation**:
  - Generic Compact Jills adjusted from 58 to 56 by removing `compact_olive_black` and `compact_sage_black`.
  - Total Compact Fleet: $8\text{ Crafted Jacks} + 56\text{ Generic Jills} = 64\text{ Steeds}$ (maintaining the symmetric 8x8 grid).
- **Security & Protection Standard**:
  - `AGENTS.md` shields placed in `Characters/Opossums/Ivan_Opossum/`, `Characters/Opossums/Isaac_Opossum/`, `System/Registry/Characters/Opossums/Compact/Crafted/Ivan_Opossum/`, `Isaac_Opossum/`, and `System/Registry/Characters/Opossums/Passel/Opossum/Ivan/`, `Isaac/`.

---

## 9. Compact Mount Narration Subsystem Specification (`Mount/Profiles/Compact/`)
- **Isolated Subdirectory Architecture**: Created `/src/System/AI/In-Game/Category/Accessibility/Narration/Mount/Profiles/Compact/` to house narration profiles for all 8 compact crafted jack opossums separately from large crafted jill opossums.
- **Compact Profile Roster**:
  1. `Drake_Kone_Reynolds` (Drake Kone-Reynolds)
  2. `Rudy_Kone_Reynolds` (Rudy Kone-Reynolds)
  3. `Eugene_Rose` (Eugene Rose)
  4. `Arnold_Rose` (Arnold Rose)
  5. `Melvin_Qin` (Melvin Qin / Melvin Chin)
  6. `Safford_Chin` (Safford Chin)
  7. `Ivan_Opossum` (Ivan Opossum)
  8. `Isaac_Opossum` (Isaac Opossum)
- **Compact Base Narration Helper (`CompactBaseNarration`)**:
  - Encapsulates exact zero-omission string formatting for compact mounts.
  - Incorporates compact rider height limit narration ("Perfect compact spacing accommodates rider heights of up to 4 feet and 4.44 inches comfortably").
  - Formats mandatory biometric parameters (`shoulder height`, `body width`, `body length`, `head width`, `head height excluding ears`) to satisfy `MountNarrationEngine.validateProfileIntegrity`.
- **Narration Registry Fortification (`Registry.tsx`)**:
  - Mapped all 8 compact IDs in `NarrationRegistry.compileRidden` and `NarrationRegistry.compileSelection`.
  - Dynamic fallback cases fortified with explicit `head width` and `head height` text literals to guarantee zero missing biometric warnings across all compact and generic mounts.

---

## 10. "Crafted By Fairies Dreams & Fantasy" 19-Jill Roster Isolation & Protection Shield Specification
- **19-Jill Roster Integrity**: `OPOSSUM_CHARACTERS` in `/src/Characters/Opossums/index.ts` is strictly isolated to contain exclusively the 19 sacred handcrafted female (Jill) opossums:
  1. Melissa Opossum (`melissa`)
  2. Ashley Opossum (`ashley`)
  3. Amara Qin (`amara_qin`)
  4. Saffron Rose (`saffron_rose`)
  5. Jalissa Chin (`jalissa_chin`)
  6. Arden-Rosie Kone-Reynolds (`arden_rosie_kone_reynolds`)
  7. Jahmella Rose (`jahmella_rose`)
  8. Dagmar Kone-Reynolds (`dagmar_kone_reynolds`)
  9. Agape Rose (`agape_rose`)
  10. Roxanne Kone-Reynolds (`roxanne_kone_reynolds`)
  11. Tiana Qin (`tiana_qin`)
  12. Wanda Opossum (`wanda`)
  13. Olivia Chin (`olivia_chin`)
  14. Ruth Kone-Reynolds (`ruth_kone_reynolds`)
  15. Kady Rose (`kady_rose`)
  16. Sandra Opossum (`sandra`)
  17. Daisy Rose (`daisy_rose`)
  18. Callie Rose (`callie_rose`)
  19. Stacey Jasmin (`stacey_jasmin`)
- **Category Categorization Safeguard**:
  - Ivan Opossum (`ivan_opossum`) and Isaac Opossum (`isaac_opossum`) are removed from `OPOSSUM_CHARACTERS` and restricted to `CRAFTED_COMPACT_DEFINITIONS` in `/src/System/Registry/Characters/Opossums/Compact/index.tsx`.
  - Guarantees zero gender/category overlap or layout confusion on the "Crafted By Fairies Dreams & Fantasy" tab.
- **Crafted Registry General & Index Fortification**:
  - `/src/System/Registry/Characters/Opossums/Crafted/General/index.tsx` includes all 19 sacred Jills in `CraftedOpossumsRegistry.characters`.
  - `/src/System/Registry/Characters/Opossums/Crafted/Index/index.tsx` exposes `validateIntegrity()` to verify 19-Jill count and zero-stub compliance.
- **Protection Lock Branch**:
  - `Crafted-By-Fairies-Dreams-And-Fantasy-Lock-Shield` branch created and synchronized to lock the 19-Jill roster and prevent dilution.

---

## 11. Upgraded Elegant Chatter Sound Architecture & Button Action Specification
- **Clean Click-Free Chatter Synthesis (`playChatterSound`)**:
  - Located in `/src/System/Sound/SFX/Category/Opossum/Elegant/Play_Chatter/index.tsx`.
  - Generates smooth exponential sweep ($1200\text{ Hz} \to 400\text{ Hz}$) over a sawtooth waveform when `isRetro = false`.
  - Eliminates clicking transients, providing an upgraded elegant chatter sound.
- **Button Audio Mapping & Preservation Standard**:
  - **"Start Game" Buttons**: Standardized across Landing Page, Interstitial Ads, and Learn Game Sounds to invoke `playProceduralSound("chatter")` (triggering clean click-free elegant chatter).
  - **"Skip Ad" Button**: Triggers `playProceduralSound("chatter")` for a clean, click-free audio transition into gameplay.
  - **Rider Selection "Next" Button**: Preserved as is.
  - **Opossum Selection Screen Buttons ("Go Back", "Next", "Ride Now")**: Preserved as is without arbitrary modification.
- **Offline Compact Synthesizer Isolation**:
  - Compact steeds route vocalizations through dedicated procedural snuffles (`playCompactOpossumSnuffle`) and chuffs (`playCompactOpossumChuff`), completely isolated from crafted Jill chatter sweeps.

---

## 12. "When Babylon Falls" BGM Restoration & Menu Integration
- **Synthesizer Engine (`src/System/Sound/BGM/Category/African/When_Babylon_Falls/index.tsx`)**:
  - 110 BPM tempo scheduler with African Pentatonic scale transposition (`AfricanPentatonic`).
  - Dual Dundun bass on beats 1 and 3; Djembe slap on beats 2 and 4; upbeat Djembe tone on beat 3.
  - Deep sub-bass resonance (`playDeepBass`) and marimba melodies (`playMarimba`).
- **Toolbox Menu Integration (`src/System/Components/Menu_Bar/Crafted/index.tsx`)**:
  - Registered `{ label: "When Babylon Falls", id: "when_babylon_falls" }` in the active track selection list.
- **Sound Engine Mapping (`src/System/Sound/index.tsx`)**:
  - Dispatches `playWhenBabylonFalls(ctx, dest)` on both `"babylon"` and `"when_babylon_falls"` track identifiers.

---

## 13. Roster Expansion: 24 Large Crafted Jills (32 Total Opossums) & 8 Riders Master Specification
- **Sacred Jill Fleet Expansion (24 Large Crafted Jills)**:
  1. Melissa (`melissa`)
  2. Ashley (`ashley`)
  3. Amara Qin (`amara_qin`)
  4. Saffron Rose (`saffron_rose`)
  5. Jalissa Chin (`jalissa_chin`)
  6. Arden-Rosie Kone-Reynolds (`arden_rosie`)
  7. Jahmella Rose (`jahmella_rose`)
  8. Dagmar Kone-Reynolds (`dagmar_kone_reynolds`)
  9. Agape Rose (`agape_rose`)
  10. Roxanne Kone-Reynolds (`roxanne_kone_reynolds`)
  11. Tiana Qin (`tiana_qin`)
  12. Wanda Opossum (`wanda`)
  13. Olivia Chin (`olivia_chin`)
  14. Ruth Kone-Reynolds (`ruth_kone_reynolds`)
  15. Kady Rose (`kady_rose`)
  16. Sandra Opossum (`sandra`)
  17. Daisy Rose (`daisy_rose`)
  18. Callie Rose (`callie_rose`)
  19. Stacey Jasmin (`stacey_jasmin`)
  20. Dale Jasmine (`dale_jasmine`) - Lavender with green roses, $5\text{ ft } 7.123\text{ in}$ shoulder, $7.1234\text{ in}$ length, gold diamond necklace, food safety advocate, smooth nose (no nostrils).
  21. Qi Jasmine (`qi_jasmine`) - Blue with green circles, $5\text{ ft } 7.123\text{ in}$ shoulder, $7.1234\text{ in}$ length, silver diamond necklace, anti-poaching tech, smooth nose (no nostrils).
  22. Jamie Jasmine (`jamie_jasmine`) - Solid silver, $5\text{ ft } 7.123\text{ in}$ shoulder, $7.1234\text{ in}$ length, weather scientist decoy, smooth nose (no nostrils).
  23. Jacinta Opossum (`jacinta_opossum`) - Solid red, $5\text{ ft } 3\text{ in}$ shoulder, $86\text{ in}$ length, twin of Camryn, gardener/scientist/poacher hunter, smooth nose (no nostrils).
  24. Camryn Opossum (`camryn_opossum`) - Light green, $5\text{ ft } 3\text{ in}$ shoulder, $86\text{ in}$ length, olive-undertone tan skin, gold paws, twin of Jacinta, smooth nose (no nostrils).
- **8 Packed Riders Master Roster**:
  1. Fairy-Rider (`fairy-rider`)
  2. Mary (`mary`)
  3. Edward (`edward`)
  4. George Blake (`george`)
  5. Angela Blake (`angela`)
  6. Sean White (`sean`)
  7. Shannon White (`shannon`)
  8. Femmy (`femmy`) - $3\text{ ft } 11\text{ in}$ height, Black ethnicity, dark-brown skin, red hair, green eyes, modest Rastafari beige onesie with black horizontal stripes and rainbow circles, flat yellow shoes. Circus actress, awareness advocate, poacher hunter hardware technician.
- **Master Equilibrium**: 24 Jills + 8 Compact Jacks = 32 Total Opossums; 8 Packed Riders.

---

## 14. Crop Fields (`Arena/Crop_Field/`), Vegetable Fields (`Arena/Vegetable_Field/`), & Aligned World 1 ("Gardens, Orchards, and Farms" `Level_0`–`Level_40`)
- **World 1 Boundaries**: Strictly bounded to **`Level_0` through `Level_40`** (41 modules). Mines reside in `World/3/`; Wilderness & Mountains reside in `World/4/`.
- **Horse Farm Alignment**: `horse_farm` slotted at `Level_18` directly before `cattle_farm` (`Level_19`).
- **Crop Fields (`Levels 20–31`, 12 Sub-Arenas)**: `wheat_field` (`20`), `corn_field` (`21`), `barley_field` (`22`), `rice_field` (`23`), `oats_field` (`24`), `sorghum_field` (`25`), `rye_field` (`26`), `millet_field` (`27`), `buckwheat_field` (`28`), `quinoa_field` (`29`), `amaranth_field` (`30`), `spelt_field` (`31`).
- **Vegetable Fields (`Levels 32–40`, 9 Sub-Arenas)**: `carrot_field` (`32`), `potato_field` (`33`), `tomato_field` (`34`), `cabbage_field` (`35`), `onion_field` (`36`), `broccoli_field` (`37`), `squash_field` (`38`), `spinach_field` (`39`), `bell_pepper_field` (`40`).
- **Triangular Slate Stone Path (`System/Building_Blocks/Triangular_Stone_Path/`)**:
  - Ground-oriented path (`pathPattern: "ground"`), sky rendering completely unaltered.
  - Paved with flat triangular **Slate** stone blocks cycling through **36 distinct colors**: White, Pink, Blue, Green, Yellow, Red, Orange, Purple, Indigo, Lavender, Silver, Gold, Bronze, Platinum, Brass, Gray, Black, Red-Orange, Yellow-Orange, Blue-Green, Blue-Violet, Red-Violet, Violet, Yellow-Green, Coral, Amber, Brown, **Caramel** (corrected from `"Carmel"`), Toffee, Tan, Peach, Ocean, Light-Green, Light-Blue, Sky Blue, Emerald.
  - Bordered along both left and right edges by **12-inch (`0.3048 m`) triangular divider stones** alternating Red, Gold, and Green.
  - Footstep Acoustics: Verified **Slate** frequency profile (`1650 Hz`, `Q = 4.8`, `gain = 1.18`, `thudFreq = 105`), prioritized ahead of generic `stone`.
- **Triangular Stone Fence Obstacle (`System/Building_Blocks/Triangular_Stone_Fence/`)**:
  - Stacked triangular slate stone fence (`1.4 m` height, `> 0.8 m` opossum jump clearance).
  - Deterministically spaced **`500 m` minimum to `2,000 m` maximum** apart across Crop & Vegetable Fields.
  - Exclusively replaces rocks, garden plants, and wooden garden fences in Crop & Vegetable Fields, with dedicated collision audio (`playTriangularStoneFenceCollision`).
- **Ethical Agriculture & Wildlife**:
  - Autonomous solar farm robotics (harvesters, sensor rovers, irrigation booms) paired with dignified human stewardship; zero slavery or plantation depictions.
  - Wildlife & Opponents: Monkeys riding moose, unmounted wild moose, feral pigs, and loose unmounted roaming monkeys (`radar` + `physics` + `Graphical_Renderer`).
- **Audio & Accessibility**:
  - Wind-rustling crop ambience (`System/Sound/BGM/Category/Ambience/Crop_Field/`).
  - Zero-fallback Accessibility Narrations (`System/AI/In-Game/Category/Accessibility/Narration/Arena/Crop_Field/` + `Vegetable_Field/` + `Registry.tsx`).

---

## 15. Wilderness Suite (`Arena/Wilderness/`) & World 4 ("The Great Outdoors, Wilderness and Mountains" `Level_1`–`Level_40`)
- **Consolidated Wilderness Folder (`src/Arena/Wilderness/`)**: Contains 5 biome families with 8 sub-arenas each (40 total):
  - `Desert/` (8), `Forest/` (8), `Plain/` (8), `Mountains/` (8), and natural `Cave/` (8 — distinct from simulated caves in `src/Arena/Cave/`).
- **World 4 Rules (`src/World/4/`)**:
  - Strictly **`Level_1` through `Level_40`** (**NO `Level_0`**, **NO `Level_N`/`Level_*`**).
  - Arranged in 8 assorted 5-biome rounds (`[Desert, Forest, Plain, Mountains, Cave] × 8`).
- **Wilderness Physics & Obstacles**:
  - Zero fences, zero garden plants, zero triangular stone fences, and zero blocking rocks.
  - Spawns elevated `"stone_platform"` structures (`width: 6.0 m`, `height: 1.1 m`) to jump onto and ride over with matched stone footsteps.
- **Wilderness Acoustics**:
  - Scientific biome ambience (`System/Sound/BGM/Category/Ambience/Wilderness/`) and terrain-specific footstep profiles (`basalt`, `limestone`, `moss`, `peat`, `silt`, `ice`, `sand`, `gravel`, `slate`, `granite`, `marble`).
- **World 2 & World 3 Alignment**:
  - World 2 decluttered to `Level_0`–`Level_7` (Temple Courtyard + 7 unique Temple arenas).
  - World 3 Index & Levels metadata aligned with Simulated & Natural Mines (`Level_0`–`Level_30`).
