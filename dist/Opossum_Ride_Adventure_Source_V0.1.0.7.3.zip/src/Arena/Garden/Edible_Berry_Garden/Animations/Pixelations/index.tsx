export const pixelAnimations = {};
