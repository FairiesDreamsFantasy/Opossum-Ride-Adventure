export const geometryAnimations = {};
